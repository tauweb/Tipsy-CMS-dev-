<?php

defined('_TEXEC') or die;

class TSessions{

public function __comstruct()
}
?>