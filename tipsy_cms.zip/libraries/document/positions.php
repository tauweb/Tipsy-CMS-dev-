<?php
// Проверяет легален ли доступ к файлу
defined('_TEXEC') or die();

class TPositions

?>