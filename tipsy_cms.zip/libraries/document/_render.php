<?php
// Проверяю легалин ли доступ
defined(_TEXEC) or die;

class TRender{

}
?>